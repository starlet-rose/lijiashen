# user-management
A 'Hello World' type CRUD user management demonstration.

## how to run

```
git clone https://github.com/gaocuiqun/user-management.git
cd user-management
mvn package
java -jar user-management-app/target/user-management-1.0-SNAPSHOT.war
```
